// ============================================================================
// convert.js
// ・入力画像を強制的に32×32pxにリサイズ（NN補間）
// ・1px＝1ブロックとして出力
// ・id を 1000 からスタート、blockId=13, textureId=100, name="art Cube" 固定
// ============================================================================

import { createRequire } from 'module';
const require = createRequire(import.meta.url);

const Jimp     = require('jimp');
const quantize = require('quantize');

import minimist from 'minimist';
import fs        from 'fs/promises';
import path      from 'path';

// ----------------------------------------------------------------------------
// CLI 引数定義
// ----------------------------------------------------------------------------
const argv = minimist(process.argv.slice(2), {
  string : ['input', 'output', 'baseName'],
  integer: [
    'maxColors', 'startId', 'blockId', 'textureId'
  ],
  alias: {
    i: 'input',  o: 'output',
    c: 'maxColors',
    s: 'startId', b: 'blockId',
    x: 'textureId', n: 'baseName'
  },
  default: {
    maxColors: 16,
    startId:   1000,
    blockId:   13,
    textureId: 100,
    baseName:  'art Cube'
  }
});

if (!argv.input || !argv.output) {
  console.error('Usage: node convert.js --input <in.png> --output <out.glol> [--maxColors N]');
  process.exit(1);
}

// ----------------------------------------------------------------------------
// 画像→.glol 変換メイン
// ----------------------------------------------------------------------------
async function convertImageToGlol(inputPath, outputPath, opts) {
  // 入力ファイル存在チェック
  try {
    await fs.access(inputPath);
  } catch {
    console.error(`❌ 入力ファイルが見つかりません: ${inputPath}`);
    process.exit(1);
  }

  // 1) 画像読み込み
  const image = await Jimp.read(inputPath);

  // 2) 強制リサイズ：32×32px（Nearest Neighbor）
  image.resize(32, 32, Jimp.RESIZE_NEAREST_NEIGHBOR);

  // ↓ ここで上下左右を反転（この一行だけ追加）
  image.flip(true, true);

  console.log('Resized → 32×32, flipped H/V');

  // 3) 全ピクセル色収集（透明は無視）
  const pixels = [];
  image.scan(0, 0, 32, 32, function(x, y, idx) {
    const alpha = this.bitmap.data[idx + 3];
    if (alpha === 0) return;
    pixels.push([
      this.bitmap.data[idx + 0],
      this.bitmap.data[idx + 1],
      this.bitmap.data[idx + 2]
    ]);
  });

  // 4) パレット量子化（出力上は色番のみ利用）
  const cmap    = quantize(pixels, opts.maxColors);
  const palette = cmap.palette();

  // 5) ブロック & グループ生成
  const blocks   = [];
  const groupDot = [];
  let idCounter  = opts.startId;  // 1000からスタート

  image.scan(0, 0, 32, 32, function(x, y, idx) {
    const alpha = this.bitmap.data[idx + 3];
    if (alpha === 0) return;

    // 最近傍パレット色インデックス
    const r = this.bitmap.data[idx + 0];
    const g = this.bitmap.data[idx + 1];
    const b = this.bitmap.data[idx + 2];
    let bestIdx = 0, bestDist = Infinity;
    palette.forEach((prgb, i) => {
      const d = (r - prgb[0])**2
              + (g - prgb[1])**2
              + (b - prgb[2])**2;
      if (d < bestDist) {
        bestDist = d;
        bestIdx  = i;
      }
    });

    blocks.push({
      id:        idCounter,
      blockId:   opts.blockId,
      name:      opts.baseName,
      textureId: opts.textureId,
      tintColor: ((palette[bestIdx][0] << 16)
                 | (palette[bestIdx][1] << 8)
                 |  palette[bestIdx][2]),
      position: {
        x: x * 5,  // 1px → 5ユニット
        y: y * 5,
        z: 0
      }
    });
    groupDot.push(idCounter);
    idCounter++;
  });

  // 6) .glol 組み立て
  const glol = {
    version: 1,
    blocks,
    groups: { dot: groupDot }
  };

  // 7) 書き出し
  const absoluteOut = path.resolve(outputPath);
  await fs.mkdir(path.dirname(absoluteOut), { recursive: true });
  await fs.writeFile(absoluteOut, JSON.stringify(glol, null, 2), 'utf-8');
  console.log(`✔ .glol created at: ${absoluteOut}`);
}

// ----------------------------------------------------------------------------
// 実行
// ----------------------------------------------------------------------------
(async () => {
  try {
    await convertImageToGlol(
      argv.input,
      argv.output,
      {
        maxColors:  argv.maxColors,
        startId:    argv.startId,
        blockId:    argv.blockId,
        textureId:  argv.textureId,
        baseName:   argv.baseName
      }
    );
  } catch (e) {
    console.error('❌ Conversion error:', e);
    process.exit(1);
  }
})();
